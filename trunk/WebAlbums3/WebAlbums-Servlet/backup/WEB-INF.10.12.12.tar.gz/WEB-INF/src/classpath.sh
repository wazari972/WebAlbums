#!/bin/sh
for i in `ls ../lib` ;  do  echo -n :../lib/$i ; done
